export type AuthUser = {
  email: string;
  password: string;
};
